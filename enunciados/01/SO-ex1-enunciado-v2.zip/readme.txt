Sistemas Operativos 2015/16

Exercício 1 - Enunciado e ficheiros de apoio
Versão 2
====================

Alterações em relação à v1:
- Pequenas gralhas corrigidas nos ficheiros commandlinereader.c e commandlinereader.h

Todos os restantes ficheiros continuam iguais à v1.
